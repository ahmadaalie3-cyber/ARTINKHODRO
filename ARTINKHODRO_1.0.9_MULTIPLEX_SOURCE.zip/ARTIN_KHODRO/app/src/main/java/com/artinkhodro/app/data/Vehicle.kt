package com.artinkhodro.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val make: String,
    val model: String,
    val yearFrom: Int? = null,
    val yearTo: Int? = null,
    val engine: String = "",
    val ecu: String = "",
    val notes: String = ""
)
