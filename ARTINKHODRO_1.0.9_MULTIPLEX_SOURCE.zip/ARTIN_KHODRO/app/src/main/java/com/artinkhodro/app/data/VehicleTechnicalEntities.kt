package com.artinkhodro.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "vehicle_sensors", indices = [Index(value = ["vehicleId", "ecuId"]), Index(value = ["nameFa"])])
data class VehicleSensor(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val ecuId: Long? = null,
    val nameFa: String,
    val locationFa: String = "",
    val connectorFa: String = "",
    val testMethodFa: String = "",
    val imageAsset: String = "",
    val source: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "diagnostic_parameters", indices = [Index(value = ["vehicleId", "ecuId"]), Index(value = ["nameFa"])])
data class DiagnosticParameter(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val ecuId: Long? = null,
    val nameFa: String,
    val unit: String = "",
    val normalRangeFa: String = "",
    val conditionsFa: String = "",
    val source: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "vehicle_fuses", indices = [Index(value = ["vehicleId", "locationFa"]), Index(value = ["vehicleId", "fuseNumber"])])
data class VehicleFuse(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val locationFa: String,
    val fuseNumber: String = "",
    val amperage: Int? = null,
    val functionFa: String = "",
    val source: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "vehicle_fault_links", indices = [Index(value = ["vehicleId", "faultCodeId"], unique = true)])
data class VehicleFaultLink(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val faultCodeId: Long,
    val ecuId: Long? = null
)
