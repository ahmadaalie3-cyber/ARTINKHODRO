package com.artinkhodro.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WiringDao {
    @Query("SELECT * FROM wiring_diagrams ORDER BY make, model, systemCategory, titleFa")
    fun observeDiagrams(): Flow<List<WiringDiagram>>

    @Query("SELECT * FROM wiring_diagrams WHERE make LIKE '%' || :term || '%' OR model LIKE '%' || :term || '%' OR titleFa LIKE '%' || :term || '%' OR systemCategory LIKE '%' || :term || '%' ORDER BY make, model LIMIT 300")
    fun searchDiagrams(term: String): Flow<List<WiringDiagram>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiagram(item: WiringDiagram): Long

    @Query("SELECT * FROM connector_pins WHERE diagramId = :diagramId ORDER BY connectorId, pinNumber")
    fun observePins(diagramId: Long): Flow<List<ConnectorPin>>

    @Query("SELECT * FROM connector_pins WHERE componentFa LIKE '%' || :term || '%' OR connectorId LIKE '%' || :term || '%' OR pinNumber LIKE '%' || :term || '%' OR circuitNameFa LIKE '%' || :term || '%' ORDER BY connectorId, pinNumber LIMIT 500")
    fun searchPins(term: String): Flow<List<ConnectorPin>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPin(item: ConnectorPin): Long

    @Query("SELECT * FROM network_nodes WHERE diagramId = :diagramId ORDER BY networkName, nodeName")
    fun observeNetworkNodes(diagramId: Long): Flow<List<NetworkNode>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNetworkNode(item: NetworkNode): Long
}
