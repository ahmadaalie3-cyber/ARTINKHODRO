package com.artinkhodro.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "technical_documents")
data class TechnicalDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titleFa: String,
    val category: String,
    val brand: String = "",
    val model: String = "",
    val assetPath: String = "",
    val sourceName: String = "",
    val permissionStatus: String = "needs_review",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "fault_codes", indices = [Index(value = ["code"], unique = true)])
data class FaultCode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val titleFa: String,
    val descriptionFa: String = "",
    val possibleCausesFa: String = "",
    val diagnosticStepsFa: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "ecu_catalog")
data class EcuRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val manufacturer: String,
    val family: String,
    val ecuType: String = "",
    val hardwareReference: String = "",
    val softwareReference: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "repair_records", indices = [Index(value = ["vehicleId"])])
data class RepairRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleLabel: String = "",
    val vehicleId: Long? = null,
    val ecuHardware: String = "",
    val symptomFa: String,
    val diagnosisFa: String = "",
    val repairActionFa: String = "",
    val repairStatus: String = "received",
    val createdAt: Long = System.currentTimeMillis()
)

/** A vehicle-specific wiring/manual record. Keep fitment scope explicit; never assume cross-trim compatibility. */
@Entity(
    tableName = "wiring_diagrams",
    indices = [Index(value = ["make", "model", "systemCategory"]), Index(value = ["sourceUrl"])]
)
data class WiringDiagram(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val make: String,
    val model: String,
    val yearFrom: Int? = null,
    val yearTo: Int? = null,
    val engineCode: String = "",
    val ecuReference: String = "",
    val systemCategory: String,
    val titleFa: String,
    val sourceName: String = "",
    val sourceUrl: String = "",
    val sourcePage: String = "",
    val permissionStatus: String = "needs_review",
    val verificationStatus: String = "needs_review",
    val notesFa: String = ""
)

/** Pin-level data is stored only after transcription from the exact matching document/revision. */
@Entity(
    tableName = "connector_pins",
    indices = [Index(value = ["diagramId", "connectorId", "pinNumber"], unique = true), Index(value = ["componentFa"])]
)
data class ConnectorPin(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val diagramId: Long,
    val connectorId: String,
    val pinNumber: String,
    val componentFa: String = "",
    val circuitNameFa: String = "",
    val wireColorCode: String = "",
    val wireColorFa: String = "",
    val originFa: String = "",
    val destinationFa: String = "",
    val expectedValue: String = "",
    val testMethodFa: String = "",
    val sourcePage: String = "",
    val verificationStatus: String = "needs_review",
    val notesFa: String = ""
)

/** Network topology records for CAN/LIN and other in-vehicle communication buses. */
@Entity(
    tableName = "network_nodes",
    indices = [Index(value = ["diagramId", "networkName", "nodeName"], unique = true)]
)
data class NetworkNode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val diagramId: Long,
    val networkName: String,
    val nodeName: String,
    val connectorId: String = "",
    val canHighPin: String = "",
    val canLowPin: String = "",
    val linPin: String = "",
    val terminationOhm: String = "",
    val sourcePage: String = "",
    val verificationStatus: String = "needs_review",
    val notesFa: String = ""
)
