package com.artinkhodro.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Vehicle::class, TechnicalDocument::class, FaultCode::class, EcuRecord::class, RepairRecord::class, WiringDiagram::class, ConnectorPin::class, NetworkNode::class, VehicleSensor::class, DiagnosticParameter::class, VehicleFuse::class, VehicleFaultLink::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun technicalDao(): TechnicalDao
    abstract fun wiringDao(): WiringDao
    abstract fun vehicleTechnicalDao(): VehicleTechnicalDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS technical_documents (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, titleFa TEXT NOT NULL, category TEXT NOT NULL, brand TEXT NOT NULL, model TEXT NOT NULL, assetPath TEXT NOT NULL, sourceName TEXT NOT NULL, permissionStatus TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS fault_codes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, code TEXT NOT NULL, titleFa TEXT NOT NULL, descriptionFa TEXT NOT NULL, possibleCausesFa TEXT NOT NULL, diagnosticStepsFa TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_fault_codes_code ON fault_codes(code)")
                db.execSQL("CREATE TABLE IF NOT EXISTS ecu_catalog (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, manufacturer TEXT NOT NULL, family TEXT NOT NULL, ecuType TEXT NOT NULL, hardwareReference TEXT NOT NULL, softwareReference TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS repair_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleLabel TEXT NOT NULL, ecuHardware TEXT NOT NULL, symptomFa TEXT NOT NULL, diagnosisFa TEXT NOT NULL, repairActionFa TEXT NOT NULL, repairStatus TEXT NOT NULL, createdAt INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DROP INDEX IF EXISTS index_fault_codes_code")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_fault_codes_code ON fault_codes(code)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS vehicle_sensors (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleId INTEGER NOT NULL, ecuId INTEGER, nameFa TEXT NOT NULL, locationFa TEXT NOT NULL, connectorFa TEXT NOT NULL, testMethodFa TEXT NOT NULL, imageAsset TEXT NOT NULL, source TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_vehicle_sensors_vehicleId_ecuId ON vehicle_sensors(vehicleId, ecuId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_vehicle_sensors_nameFa ON vehicle_sensors(nameFa)")
                db.execSQL("CREATE TABLE IF NOT EXISTS diagnostic_parameters (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleId INTEGER NOT NULL, ecuId INTEGER, nameFa TEXT NOT NULL, unit TEXT NOT NULL, normalRangeFa TEXT NOT NULL, conditionsFa TEXT NOT NULL, source TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_diagnostic_parameters_vehicleId_ecuId ON diagnostic_parameters(vehicleId, ecuId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_diagnostic_parameters_nameFa ON diagnostic_parameters(nameFa)")
                db.execSQL("CREATE TABLE IF NOT EXISTS vehicle_fuses (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleId INTEGER NOT NULL, locationFa TEXT NOT NULL, fuseNumber TEXT NOT NULL, amperage INTEGER, functionFa TEXT NOT NULL, source TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_vehicle_fuses_vehicleId_locationFa ON vehicle_fuses(vehicleId, locationFa)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_vehicle_fuses_vehicleId_fuseNumber ON vehicle_fuses(vehicleId, fuseNumber)")
                db.execSQL("CREATE TABLE IF NOT EXISTS vehicle_fault_links (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleId INTEGER NOT NULL, faultCodeId INTEGER NOT NULL, ecuId INTEGER)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_vehicle_fault_links_vehicleId_faultCodeId ON vehicle_fault_links(vehicleId, faultCodeId)")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE repair_records ADD COLUMN vehicleId INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_repair_records_vehicleId ON repair_records(vehicleId)")
            }
        }

        private val DEFAULT_DTC = listOf(
            arrayOf("P0100", "اختلال مدار سنسور جریان هوای ورودی MAF", "مدار اندازه‌گیری جریان هوای ورودی سیگنال معتبر ارسال نمی‌کند.", "قطعی یا اتصال کوتاه سیم‌کشی؛ سوکت معیوب؛ تغذیه یا اتصال بدنه نامناسب؛ خرابی MAF.", "ابتدا ولتاژ تغذیه و افت ولتاژ بدنه را طبق نقشه همان خودرو بررسی کنید؛ سپس پیوستگی سیم سیگنال و داده زنده MAF را با شرایط سازنده مقایسه کنید."),
            arrayOf("P0101", "عملکرد خارج از محدوده سنسور MAF", "مقدار اندازه‌گیری‌شده با شرایط کاری موتور همخوانی ندارد.", "نشتی هوای بعد از MAF؛ فیلتر یا مسیر هوای مسدود؛ آلودگی سنسور؛ نشتی خلأ؛ ایراد سیم‌کشی.", "مسیر ورودی هوا و بست‌ها را بازدید کنید؛ نشتی دود را بررسی و داده MAF را در دور آرام و افزایش دور با مشخصات همان موتور مقایسه کنید."),
            arrayOf("P0113", "ورودی زیاد مدار سنسور دمای هوای ورودی IAT", "ECU ولتاژ بالای غیرعادی در مدار IAT تشخیص داده است.", "قطعی مدار یا سوکت؛ اتصال بدنه نامناسب؛ خرابی سنسور یا سیم سیگنال.", "دمای IAT در حالت موتور سرد را با دمای محیط مقایسه کنید؛ سوکت، مرجع و سیم‌کشی را طبق نقشه بررسی کنید."),
            arrayOf("P0128", "دمای مایع خنک‌کننده کمتر از دمای تنظیمی", "دمای موتور در زمان مورد انتظار به محدوده کاری تعریف‌شده نرسیده است.", "ترموستات بازمانده؛ سطح پایین مایع؛ سنسور ECT یا سیم‌کشی؛ شرایط رانندگی یا کالیبراسیون خاص.", "سطح مایع را فقط در موتور سرد بررسی کنید؛ روند گرم‌شدن ECT و عملکرد ترموستات را مطابق دستورالعمل سازنده ارزیابی کنید."),
            arrayOf("P0130", "اختلال مدار سنسور اکسیژن بانک ۱ سنسور ۱", "ECU عملکرد الکتریکی مدار سنسور اکسیژن بالادست بانک ۱ را نامعتبر تشخیص داده است.", "سوکت یا سیم‌کشی آسیب‌دیده؛ نشتی اگزوز؛ تغذیه گرم‌کن؛ سنسور معیوب.", "نوع سنسور و نقشه پایه‌ها را شناسایی کنید؛ سیم‌کشی و گرم‌کن را تست و سیگنال را با ابزار مناسب و مشخصات خودرو ارزیابی کنید."),
            arrayOf("P0171", "مخلوط سوخت و هوا بیش از حد رقیق در بانک ۱", "اصلاح سوخت ECU نشان‌دهنده کمبود سوخت یا هوای اضافی است.", "نشتی خلأ یا هوای ورودی؛ فشار یا دبی سوخت ناکافی؛ MAF آلوده؛ نشتی اگزوز پیش از سنسور.", "Fuel Trim کوتاه‌مدت و بلندمدت را در شرایط مختلف بررسی کنید؛ تست دود، فشار سوخت و داده MAF را طبق مشخصات موتور انجام دهید."),
            arrayOf("P0300", "احتراق ناقص تصادفی یا چند سیلندر", "ECU وقوع احتراق ناقص را در یک یا چند سیلندر تشخیص داده است.", "شمع یا کوئل؛ انژکتور؛ فشار سوخت؛ نشتی هوا؛ تراکم مکانیکی نامناسب.", "شمارنده Misfire و Freeze Frame را بخوانید؛ جرقه، سوخت و تراکم را مرحله‌ای بررسی کنید؛ در صورت چشمک‌زدن چراغ MIL از ادامه رانندگی پرهیز کنید."),
            arrayOf("P0420", "بازده کاتالیزور کمتر از آستانه؛ بانک ۱", "مقایسه سیگنال سنسورهای اکسیژن نشان‌دهنده بازده پایین کاتالیزور است.", "کاتالیزور فرسوده؛ نشتی اگزوز؛ احتراق ناقص؛ اختلال سنسور اکسیژن یا مخلوط سوخت.", "پیش از محکوم‌کردن کاتالیزور، خطاهای احتراق و سوخت را رفع کنید؛ نشتی اگزوز و عملکرد سنسورها را طبق روش سازنده بسنجید."),
            arrayOf("P0442", "نشتی کوچک در سامانه کنترل بخارات سوخت EVAP", "سامانه EVAP نشتی کوچک یا عدم آب‌بندی را تشخیص داده است.", "درپوش باک نامناسب؛ شلنگ یا اتصالات نشتی‌دار؛ شیر purge یا vent؛ کنیستر آسیب‌دیده.", "درپوش و آب‌بندی را بررسی کنید؛ تست دود EVAP را فقط با دستگاه و فشار مجاز سازنده انجام دهید."),
            arrayOf("P0500", "اختلال سیگنال سرعت خودرو", "ECU سیگنال سرعت معتبر دریافت نمی‌کند.", "سنسور سرعت؛ سیم‌کشی؛ تغذیه و بدنه؛ ایراد شبکه یا واحد تولیدکننده سرعت.", "سرعت چرخ‌ها و خودرو را در داده زنده یونیت‌های مرتبط مقایسه کنید؛ مسیر سیگنال و شبکه را بر اساس نقشه همان خودرو بررسی کنید."),
            arrayOf("P0562", "ولتاژ پایین سامانه برق خودرو", "ولتاژ تغذیه ثبت‌شده توسط ECU پایین‌تر از محدوده مورد انتظار بوده است.", "باتری ضعیف؛ اتصالات یا کابل بدنه معیوب؛ شارژ ناکافی؛ افت ولتاژ در مدار تغذیه.", "باتری را با روش استاندارد تست کنید؛ ولتاژ شارژ و افت ولتاژ مثبت و بدنه را زیر بار اندازه بگیرید؛ اتصالات را بازدید کنید."),
            arrayOf("P0700", "درخواست روشن‌شدن چراغ اخطار از سامانه کنترل گیربکس", "ECU موتور اعلام کرده است که TCM خطای مرتبط با گیربکس ثبت کرده؛ این کد به‌تنهایی علت را مشخص نمی‌کند.", "وجود کدهای اختصاصی در TCM؛ ایراد برقی، هیدرولیکی یا مکانیکی گیربکس؛ ارتباط شبکه.", "با دستگاه سازگار وارد TCM شوید و کدهای اختصاصی و Freeze Frame را بخوانید؛ از تعویض قطعه صرفاً بر اساس P0700 خودداری کنید.")
        )

        // فهرست شروع برای نمایش اولیه خودروها؛ اطلاعات فنی هر تیپ باید جداگانه تأیید شود.
        private val STARTER_VEHICLES = listOf(
            arrayOf("ایران‌خودرو", "پژو ۲۰۶"), arrayOf("ایران‌خودرو", "پژو ۲۰۷"),
            arrayOf("ایران‌خودرو", "پژو ۴۰۵"), arrayOf("ایران‌خودرو", "پارس"),
            arrayOf("ایران‌خودرو", "سمند"), arrayOf("ایران‌خودرو", "سورن"),
            arrayOf("ایران‌خودرو", "دنا"), arrayOf("ایران‌خودرو", "دنا پلاس"),
            arrayOf("ایران‌خودرو", "رانا"), arrayOf("ایران‌خودرو", "تارا"),
            arrayOf("سایپا", "پراید"), arrayOf("سایپا", "تیبا"), arrayOf("سایپا", "ساینا"),
            arrayOf("سایپا", "کوییک"), arrayOf("سایپا", "شاهین"),
            arrayOf("مدیران خودرو", "MVM 110"), arrayOf("مدیران خودرو", "MVM 315"),
            arrayOf("مدیران خودرو", "MVM X22"), arrayOf("مدیران خودرو", "MVM X33"),
            arrayOf("مدیران خودرو", "MVM X55"), arrayOf("چری", "Tiggo 5"),
            arrayOf("چری", "Tiggo 7"), arrayOf("چری", "Tiggo 8"),
            arrayOf("چری", "Arrizo 5"), arrayOf("جک", "J3"), arrayOf("جک", "J4"),
            arrayOf("جک", "J5"), arrayOf("جک", "S3"), arrayOf("جک", "S5"),
            arrayOf("جک", "T8"), arrayOf("لیفان", "X50"), arrayOf("لیفان", "X60"),
            arrayOf("برلیانس", "H220"), arrayOf("برلیانس", "H320"), arrayOf("برلیانس", "H330"),
            arrayOf("Hyundai", "Elantra"), arrayOf("Hyundai", "Sonata"),
            arrayOf("Hyundai", "Tucson"), arrayOf("Hyundai", "Santa Fe"),
            arrayOf("Kia", "Cerato"), arrayOf("Kia", "Optima"), arrayOf("Kia", "Sportage"),
            arrayOf("Toyota", "Corolla"), arrayOf("Toyota", "Camry"), arrayOf("Toyota", "RAV4"),
            arrayOf("Renault", "Logan"), arrayOf("Renault", "Sandero"), arrayOf("Renault", "Megane"),
            arrayOf("Mercedes-Benz", "C-Class"), arrayOf("Mercedes-Benz", "E-Class"),
            arrayOf("BMW", "3 Series"), arrayOf("BMW", "5 Series")
        )

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS wiring_diagrams (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, make TEXT NOT NULL, model TEXT NOT NULL, yearFrom INTEGER, yearTo INTEGER, engineCode TEXT NOT NULL, ecuReference TEXT NOT NULL, systemCategory TEXT NOT NULL, titleFa TEXT NOT NULL, sourceName TEXT NOT NULL, sourceUrl TEXT NOT NULL, sourcePage TEXT NOT NULL, permissionStatus TEXT NOT NULL, verificationStatus TEXT NOT NULL, notesFa TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_wiring_diagrams_make_model_systemCategory ON wiring_diagrams(make, model, systemCategory)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_wiring_diagrams_sourceUrl ON wiring_diagrams(sourceUrl)")
                db.execSQL("CREATE TABLE IF NOT EXISTS connector_pins (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, diagramId INTEGER NOT NULL, connectorId TEXT NOT NULL, pinNumber TEXT NOT NULL, componentFa TEXT NOT NULL, circuitNameFa TEXT NOT NULL, wireColorCode TEXT NOT NULL, wireColorFa TEXT NOT NULL, originFa TEXT NOT NULL, destinationFa TEXT NOT NULL, expectedValue TEXT NOT NULL, testMethodFa TEXT NOT NULL, sourcePage TEXT NOT NULL, verificationStatus TEXT NOT NULL, notesFa TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_connector_pins_diagramId_connectorId_pinNumber ON connector_pins(diagramId, connectorId, pinNumber)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_connector_pins_componentFa ON connector_pins(componentFa)")
                db.execSQL("CREATE TABLE IF NOT EXISTS network_nodes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, diagramId INTEGER NOT NULL, networkName TEXT NOT NULL, nodeName TEXT NOT NULL, connectorId TEXT NOT NULL, canHighPin TEXT NOT NULL, canLowPin TEXT NOT NULL, linPin TEXT NOT NULL, terminationOhm TEXT NOT NULL, sourcePage TEXT NOT NULL, verificationStatus TEXT NOT NULL, notesFa TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_network_nodes_diagramId_networkName_nodeName ON network_nodes(diagramId, networkName, nodeName)")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "artin_khodro.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onOpen(db: SupportSQLiteDatabase) {
                        super.onOpen(db)
                        db.beginTransaction()
                        try {
                            DEFAULT_DTC.forEach { row ->
                                db.execSQL(
                                    "INSERT OR IGNORE INTO fault_codes (code, titleFa, descriptionFa, possibleCausesFa, diagnosticStepsFa, verificationStatus) VALUES (?, ?, ?, ?, ?, ?)",
                                    arrayOf<Any>(row[0], row[1], row[2], row[3], row[4], "generic_reference_review_vehicle")
                                )
                            }
                            db.query("SELECT COUNT(*) FROM vehicles").use { cursor ->
                                if (cursor.moveToFirst() && cursor.getInt(0) == 0) {
                                    STARTER_VEHICLES.forEach { row ->
                                        db.execSQL(
                                            "INSERT INTO vehicles (make, model, yearFrom, yearTo, engine, ecu, notes) VALUES (?, ?, NULL, NULL, '', '', ?)",
                                            arrayOf<Any>(row[0], row[1], "فهرست اولیه؛ مشخصات تیپ و ECU نیازمند تطبیق با VIN و مستند سازنده است.")
                                        )
                                    }
                                }
                            }
                            db.setTransactionSuccessful()
                        } finally {
                            db.endTransaction()
                        }
                    }
                }).build().also { INSTANCE = it }
        }
    }
}
