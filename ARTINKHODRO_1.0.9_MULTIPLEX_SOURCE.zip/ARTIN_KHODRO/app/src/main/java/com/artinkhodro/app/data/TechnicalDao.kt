package com.artinkhodro.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TechnicalDao {
    @Query("SELECT * FROM technical_documents ORDER BY category, titleFa")
    fun observeDocuments(): Flow<List<TechnicalDocument>>

    @Query("SELECT * FROM technical_documents WHERE titleFa LIKE '%' || :term || '%' OR category LIKE '%' || :term || '%' OR brand LIKE '%' || :term || '%' OR model LIKE '%' || :term || '%' ORDER BY titleFa")
    fun searchDocuments(term: String): Flow<List<TechnicalDocument>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(item: TechnicalDocument): Long

    @Query("SELECT * FROM fault_codes WHERE code LIKE '%' || :term || '%' OR titleFa LIKE '%' || :term || '%' ORDER BY code LIMIT 200")
    fun searchFaultCodes(term: String): Flow<List<FaultCode>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFaultCode(item: FaultCode): Long

    @Query("SELECT * FROM ecu_catalog WHERE manufacturer LIKE '%' || :term || '%' OR family LIKE '%' || :term || '%' OR hardwareReference LIKE '%' || :term || '%' ORDER BY manufacturer, family")
    fun searchEcus(term: String): Flow<List<EcuRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEcu(item: EcuRecord): Long

    @Query("SELECT * FROM repair_records ORDER BY createdAt DESC")
    fun observeRepairs(): Flow<List<RepairRecord>>

    @Query("SELECT * FROM repair_records WHERE vehicleId = :vehicleId ORDER BY createdAt DESC")
    fun repairsForVehicle(vehicleId: Long): Flow<List<RepairRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepair(item: RepairRecord): Long
}
