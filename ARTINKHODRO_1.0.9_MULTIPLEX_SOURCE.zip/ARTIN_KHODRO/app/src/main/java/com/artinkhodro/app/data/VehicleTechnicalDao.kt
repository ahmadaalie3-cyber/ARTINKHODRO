package com.artinkhodro.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleTechnicalDao {
    @Query("SELECT * FROM vehicle_sensors WHERE vehicleId = :vehicleId ORDER BY nameFa")
    fun sensorsForVehicle(vehicleId: Long): Flow<List<VehicleSensor>>

    @Query("SELECT * FROM diagnostic_parameters WHERE vehicleId = :vehicleId ORDER BY nameFa")
    fun parametersForVehicle(vehicleId: Long): Flow<List<DiagnosticParameter>>

    @Query("SELECT * FROM vehicle_fuses WHERE vehicleId = :vehicleId ORDER BY locationFa, fuseNumber")
    fun fusesForVehicle(vehicleId: Long): Flow<List<VehicleFuse>>

    @Query("SELECT fault_codes.* FROM fault_codes INNER JOIN vehicle_fault_links ON fault_codes.id = vehicle_fault_links.faultCodeId WHERE vehicle_fault_links.vehicleId = :vehicleId ORDER BY fault_codes.code")
    fun faultCodesForVehicle(vehicleId: Long): Flow<List<FaultCode>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSensor(item: VehicleSensor): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParameter(item: DiagnosticParameter): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFuse(item: VehicleFuse): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun linkFaultCode(item: VehicleFaultLink): Long
}
